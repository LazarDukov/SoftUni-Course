package handball.entities.gameplay;

public class Indoor extends BaseGameplay {
    public Indoor(String name) {
        super(name, 250);
    }
}
