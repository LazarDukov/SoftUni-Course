package handball.core;

public interface Engine extends Runnable{
}
